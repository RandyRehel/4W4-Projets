<div id="sidebar-footer_colonne_2" class="sidebar">
    <?php dynamic_sidebar( 'footer_colonne_2' ); ?>
</div>