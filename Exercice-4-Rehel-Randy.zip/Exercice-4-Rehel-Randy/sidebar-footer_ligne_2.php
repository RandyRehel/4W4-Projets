<div id="sidebar-footer_ligne_2" class="sidebar">
    <?php dynamic_sidebar( 'footer_ligne_2' ); ?>
</div>