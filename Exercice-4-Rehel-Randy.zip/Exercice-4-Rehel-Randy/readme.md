# 4w4 - Conception d'interface et développement Web
### Auteur : Randy Rehel


Développement des deux menus de blocs de navigations:
- Pages des Evenements
- Pages des departements

Développement d'une galerie d'images de la vie etudiante

Développement de la grille de cours amelioree avec des boites modales

Design plus beau a venir dans le TP2
 

Pour modifier readme.md
https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax